package com.antechrist.adherentsapp.domain.model

data class GuardianInvitation(
    val id: String,
    val guardianId: String,
    val emailLower: String,
    val seasonKey: String,
    val status: String
)
