package com.antechrist.adherentsapp.ui.screens.parent

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.antechrist.adherentsapp.domain.usecase.AcceptGuardianInvitationUseCase
import com.antechrist.adherentsapp.domain.usecase.GetPendingGuardianInvitationForCurrentUserUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class ParentActivationState { Loading, Success, NoInvite, Error }

data class ParentActivationUi(
    val state: ParentActivationState = ParentActivationState.Loading,
    val error: String? = null
)

@HiltViewModel
class ParentActivationViewModel @Inject constructor(
    private val getPendingInvite: GetPendingGuardianInvitationForCurrentUserUseCase,
    private val acceptInvite: AcceptGuardianInvitationUseCase
) : ViewModel() {

    private val _ui = MutableStateFlow(ParentActivationUi())
    val ui: StateFlow<ParentActivationUi> = _ui.asStateFlow()

    fun start() {
        viewModelScope.launch {
            _ui.update { it.copy(state = ParentActivationState.Loading, error = null) }

            try {
                val invite = getPendingInvite()
                if (invite == null) {
                    _ui.update { it.copy(state = ParentActivationState.NoInvite) }
                    return@launch
                }

                acceptInvite(invite.id, invite.guardianId)
                _ui.update { it.copy(state = ParentActivationState.Success) }
            } catch (e: Exception) {
                _ui.update { it.copy(state = ParentActivationState.Error, error = e.message) }
            }
        }
    }
}
