package com.antechrist.adherentsapp.data.firestore

import com.antechrist.adherentsapp.domain.model.GuardianInvitation
import com.antechrist.adherentsapp.domain.repository.GuardianInvitationsRepository
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class GuardianInvitationsRepositoryImpl @Inject constructor(
    private val db: FirebaseFirestore
) : GuardianInvitationsRepository {

    private val col = db.collection("guardian_invitations")
    private val guardians = db.collection("guardians")

    override suspend fun findPendingFor(emailLower: String, seasonKey: String): GuardianInvitation? {
        val qs = col
            .whereEqualTo("emailLower", emailLower)
            .whereEqualTo("seasonKey", seasonKey)
            .whereEqualTo("status", "PENDING")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(1)
            .get()
            .await()

        val doc = qs.documents.firstOrNull() ?: return null
        return GuardianInvitation(
            id = doc.id,
            guardianId = doc.getString("guardianId") ?: return null,
            emailLower = doc.getString("emailLower") ?: emailLower,
            seasonKey = doc.getString("seasonKey") ?: seasonKey,
            status = doc.getString("status") ?: "PENDING"
        )
    }

    override suspend fun accept(inviteId: String, guardianId: String, authUid: String) {
        val inviteRef = col.document(inviteId)
        val guardianRef = guardians.document(guardianId)

        val batch = db.batch()

        // 1) Invitation -> ACCEPTED
        batch.set(
            inviteRef,
            mapOf(
                "status" to "ACCEPTED",
                "acceptedByUid" to authUid,
                "acceptedAt" to System.currentTimeMillis()
            ),
            SetOptions.merge()
        )

        // 2) Guardian -> authUid
        batch.set(
            guardianRef,
            mapOf(
                "authUid" to authUid,
                "updatedAt" to System.currentTimeMillis()
            ),
            SetOptions.merge()
        )

        batch.commit().await()
    }
    override suspend fun findLatestPendingForEmail(emailLower: String): GuardianInvitation? {
        val e = emailLower.trim().lowercase()
        if (e.isEmpty()) return null

        val qs = col
            .whereEqualTo("emailLower", e)
            .whereEqualTo("status", "PENDING")
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(1)
            .get()
            .await()

        val doc = qs.documents.firstOrNull() ?: return null

        val guardianId = doc.getString("guardianId") ?: return null
        val seasonKey = doc.getString("seasonKey") ?: ""

        return com.antechrist.adherentsapp.domain.model.GuardianInvitation(
            id = doc.id,
            guardianId = guardianId,
            emailLower = doc.getString("emailLower") ?: e,
            seasonKey = seasonKey,
            status = doc.getString("status") ?: "PENDING"
        )
    }
}
