package com.antechrist.adherentsapp.domain.usecase

import com.antechrist.adherentsapp.domain.model.Guardian
import com.antechrist.adherentsapp.domain.repository.GuardiansRepository
import javax.inject.Inject

class GetGuardianForCurrentUserUseCase @Inject constructor(
    private val repo: GuardiansRepository
) {
    suspend operator fun invoke(authUid: String): Guardian? {
        return repo.getByAuthUid(authUid)
    }
}
