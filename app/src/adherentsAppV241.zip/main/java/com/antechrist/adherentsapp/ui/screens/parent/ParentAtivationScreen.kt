package com.antechrist.adherentsapp.ui.screens.parent

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun ParentActivationScreen(
    onDone: () -> Unit,
    onBackToLogin: () -> Unit,
    vm: ParentActivationViewModel = hiltViewModel()
) {
    val ui by vm.ui.collectAsState()

    LaunchedEffect(Unit) { vm.start() }

    Box(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Activation parent", style = MaterialTheme.typography.titleLarge)

            when (ui.state) {
                ParentActivationState.Loading -> {
                    CircularProgressIndicator()
                    Text("Vérification de l’invitation en cours…")
                }

                ParentActivationState.Success -> {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Text("Compte activé ✅")
                    Text(
                        "Ton accès parent est maintenant lié au responsable. " +
                                "L’espace parent sera branché ensuite.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
                        Text("Continuer")
                    }
                }

                ParentActivationState.NoInvite -> {
                    Text("Aucune invitation en attente pour ce compte.")
                    Text(
                        "Demande au club de t’envoyer une invitation depuis la fiche adhérent.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = onBackToLogin, modifier = Modifier.fillMaxWidth()) {
                        Text("Retour")
                    }
                }

                ParentActivationState.Error -> {
                    Text("Erreur : ${ui.error ?: "inconnue"}", color = MaterialTheme.colorScheme.error)
                    Button(onClick = vm::start, modifier = Modifier.fillMaxWidth()) {
                        Text("Réessayer")
                    }
                    OutlinedButton(onClick = onBackToLogin, modifier = Modifier.fillMaxWidth()) {
                        Text("Retour")
                    }
                }
            }
        }
    }
}
