package com.antechrist.adherentsapp.domain.usecase

import com.antechrist.adherentsapp.domain.model.GuardianInvitation
import com.antechrist.adherentsapp.domain.repository.GuardianInvitationsRepository
import com.google.firebase.auth.FirebaseAuth
import javax.inject.Inject

class GetPendingGuardianInvitationForCurrentUserUseCase @Inject constructor(
    private val repo: GuardianInvitationsRepository
) {
    suspend operator fun invoke(): GuardianInvitation? {
        val email = FirebaseAuth.getInstance()
            .currentUser
            ?.email
            ?.trim()
            ?.lowercase()
            ?: return null

        // ⚠️ IMPORTANT :
        // On NE filtre PAS par seasonKey ici.
        // Un parent accepte une invitation PENDING, point.
        return repo.findLatestPendingForEmail(emailLower = email)
    }
}
