package com.antechrist.adherentsapp.data.auth

import android.util.Log
import com.antechrist.adherentsapp.domain.repository.AuthRepository
import com.antechrist.adherentsapp.domain.repository.AuthStatus
import javax.inject.Inject

/**
 * Implémentation du AuthRepository qui orchestre
 * les appels à AuthDataSource et interprète les claims.
 */
class AuthRepositoryImpl @Inject constructor(
    private val ds: AuthDataSource
) : AuthRepository {

    override suspend fun signIn(email: String, password: String): AuthStatus {
        ds.signIn(email, password)
        return refreshStatus()
    }

    override suspend fun signOut() {
        ds.signOut()
    }

    override suspend fun refreshStatus(): AuthStatus {
        val user = ds.currentUser()
        if (user == null) {
            return AuthStatus(isAuthenticated = false, isAdmin = false, email = null)
        }

        val claims = ds.refreshIdTokenAndGetClaims()
        Log.d("AuthRepo", "claims=$claims")
        val role = (claims["role"] as? String)?.lowercase()
        val isAdmin = when (role) {
            "super_admin", "admin", "bureau" -> true
            else -> false
        }

        return AuthStatus(
            isAuthenticated = true,
            isAdmin = isAdmin,
            email = user.email
        )
    }

    override fun currentEmailOrNull(): String? = ds.currentUser()?.email
}
