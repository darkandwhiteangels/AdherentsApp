package com.antechrist.adherentsapp.ui.screens.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.antechrist.adherentsapp.domain.model.Role
import com.antechrist.adherentsapp.domain.model.isStaff
import com.antechrist.adherentsapp.domain.model.roleFromString
import com.antechrist.adherentsapp.domain.repository.AuthRepository
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val loading: Boolean = false,
    val error: String? = null
)

sealed interface LoginNav {
    data object None : LoginNav
    data object GoList : LoginNav
    data object GoAccessDenied : LoginNav
}

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val authRepo: AuthRepository
) : ViewModel() {

    private val _ui = MutableStateFlow(LoginUiState())
    val ui: StateFlow<LoginUiState> = _ui.asStateFlow()

    private val _nav = MutableStateFlow<LoginNav>(LoginNav.None)
    val nav: StateFlow<LoginNav> = _nav.asStateFlow()

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    fun onEmailChange(v: String) = _ui.update { it.copy(email = v, error = null) }
    fun onPasswordChange(v: String) = _ui.update { it.copy(password = v, error = null) }

    fun signIn() {
        val email = _ui.value.email.trim()
        val pass = _ui.value.password

        if (email.isEmpty() || pass.isEmpty()) {
            _ui.update { it.copy(error = "Email et mot de passe requis.") }
            return
        }

        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null) }
            try {
                // 1) Connexion (ton repo fait déjà le refresh des claims côté serveur si besoin)
                authRepo.signIn(email, pass)

                // 2) Récupère un ID token FRAIS pour lire le claim "role"
                val token = auth.currentUser?.getIdToken(true)?.await()
                val rawRole = token?.claims?.get("role")?.toString()
                val role: Role = roleFromString(rawRole)

                // 3) Gating : staff OU (trésorier / secrétaire) = accès
                val authorized =
                    role.isStaff() || role == Role.TRESORIER || role == Role.SECRETAIRE

                _ui.update { it.copy(loading = false) }
                _nav.value = if (authorized) LoginNav.GoList else LoginNav.GoAccessDenied
            } catch (e: Exception) {
                _ui.update { it.copy(loading = false, error = e.message ?: "Erreur de connexion") }
            }
        }
    }

    fun consumeNav() { _nav.value = LoginNav.None }
}
