package com.antechrist.adherentsapp.ui.screens.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.antechrist.adherentsapp.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface SplashNav { data object None: SplashNav; data object ToLogin: SplashNav; data object ToList: SplashNav; data object ToDenied: SplashNav }

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val auth: AuthRepository
) : ViewModel() {
    private val _nav = MutableStateFlow<SplashNav>(SplashNav.None)
    val nav: StateFlow<SplashNav> = _nav

    fun check() {
        viewModelScope.launch {
            try {
                val st = auth.refreshStatus() // lit claims
                _nav.value = when {
                    !st.isAuthenticated -> SplashNav.ToLogin
                    st.isAdmin -> SplashNav.ToList
                    else -> SplashNav.ToDenied
                }
            } catch (_: Exception) {
                _nav.value = SplashNav.ToLogin
            }
        }
    }
}
