package com.antechrist.adherentsapp.data.firestore

import com.antechrist.adherentsapp.domain.model.Guardian
import com.antechrist.adherentsapp.domain.repository.GuardiansRepository
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GuardiansRepositoryImpl @Inject constructor(
    private val db: FirebaseFirestore
) : GuardiansRepository {

    private val colGuardians by lazy { db.collection("guardians") }
    private val colAdherents by lazy { db.collection("adherents") }

    override suspend fun getById(id: String): Guardian? {
        val snap = colGuardians.document(id).get().await()
        return if (snap.exists()) snap.toGuardian() else null
    }

    override fun streamAll(): Flow<List<Guardian>> = callbackFlow {
        val sub = colGuardians
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .limit(500)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    android.util.Log.e("GuardiansRepo", "streamAll error", err)
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents?.map { it.toGuardian() } ?: emptyList()
                trySend(
                    list.sortedWith(compareBy<Guardian> { (it.nom ?: "").trim() }.thenBy { (it.prenom ?: "").trim() })
                )
            }
        awaitClose { sub.remove() }
    }

    override suspend fun update(guardian: Guardian) {
        require(guardian.id.isNotBlank()) { "Guardian id manquant" }
        colGuardians.document(guardian.id).set(guardian.toMap(), SetOptions.merge()).await()
    }

    override suspend fun findByEmailOrTel(email: String?, telephoneDigits: String?): Guardian? {
        val e = email?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        val t = telephoneDigits?.filter { it.isDigit() }?.takeIf { it.isNotEmpty() }

        var found: Guardian? = null

        if (e != null) {
            val qs = colGuardians.whereEqualTo("email", e).limit(1).get().await()
            found = qs.documents.firstOrNull()?.toGuardian()
        }
        if (found == null && t != null) {
            val qs = colGuardians.whereEqualTo("telephone", t).limit(1).get().await()
            found = qs.documents.firstOrNull()?.toGuardian()
        }
        return found
    }

    override suspend fun createGuardian(
        nom: String,
        prenom: String,
        email: String?,
        telephoneDigits: String?,
        relation: String?
    ): String {
        val t = telephoneDigits?.filter { it.isDigit() }?.takeIf { it.isNotEmpty() }
        val e = email?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        require(!e.isNullOrEmpty() || !t.isNullOrEmpty()) {
            "Email ou téléphone requis"
        }

        val doc = colGuardians.document()
        val data = hashMapOf<String, Any?>(
            "nom" to nom,
            "prenom" to prenom,
            "relation" to relation,
            "telephone" to t,
            "email" to e,
            "updatedAt" to System.currentTimeMillis(),
            "createdAt" to System.currentTimeMillis()
        )
        doc.set(data, SetOptions.merge()).await()
        return doc.id
    }

    override suspend fun linkGuardianToAdherent(
        adherentId: String,
        guardianId: String,
        setPrimaryIfEmpty: Boolean
    ) {
        val aRef = colAdherents.document(adherentId)
        db.runTransaction { tr ->
            val snap = tr.get(aRef)
            val guardianIds = (snap.get("guardianIds") as? List<*>)?.mapNotNull { it as? String }?.toMutableSet() ?: mutableSetOf()
            val primary = snap.getString("primaryGuardianId")

            guardianIds.add(guardianId)
            val updates = hashMapOf<String, Any?>(
                "guardianIds" to guardianIds.toList(),
                "updatedAt" to System.currentTimeMillis()
            )
            if (setPrimaryIfEmpty && primary.isNullOrBlank()) {
                updates["primaryGuardianId"] = guardianId
            }
            tr.update(aRef, updates as Map<String, Any?>)
            null
        }.await()
    }

    override suspend fun unlinkGuardianFromAdherent(
        adherentId: String,
        guardianId: String
    ) {
        val aRef = colAdherents.document(adherentId)
        db.runTransaction { tr ->
            val snap = tr.get(aRef)
            val guardianIds = (snap.get("guardianIds") as? List<*>)?.mapNotNull { it as? String }?.toMutableList() ?: mutableListOf()
            val primary = snap.getString("primaryGuardianId")

            // remove id
            val newList = guardianIds.filter { it != guardianId }
            val updates = hashMapOf<String, Any?>(
                "guardianIds" to newList,
                "updatedAt" to System.currentTimeMillis()
            )
            if (primary == guardianId) {
                // si on supprime le principal : mettre null ou premier restant
                updates["primaryGuardianId"] = newList.firstOrNull()
            }
            tr.update(aRef, updates as Map<String, Any?>)
            null
        }.await()
    }

    override suspend fun setPrimaryGuardian(adherentId: String, guardianId: String) {
        val aRef = colAdherents.document(adherentId)
        db.runTransaction { tr ->
            val snap = tr.get(aRef)
            val guardianIds = (snap.get("guardianIds") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
            val updates = hashMapOf<String, Any?>(
                "updatedAt" to System.currentTimeMillis(),
                "primaryGuardianId" to guardianId
            )
            // S'assurer qu'il est dans la liste
            if (!guardianIds.contains(guardianId)) {
                tr.update(aRef, "guardianIds", FieldValue.arrayUnion(guardianId))
            }
            tr.update(aRef, updates as Map<String, Any?>)
            null
        }.await()
    }
}
