package com.antechrist.adherentsapp.ui.screens.guardian

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

data class GuardianUi(
    val id: String,
    val nom: String,
    val prenom: String,
    val email: String?,
    val telephone: String?,
    val ville: String?,
    val relation: String?
)

data class GuardianListState(
    val loading: Boolean = false,
    val error: String? = null,
    val items: List<GuardianUi> = emptyList(),
    val query: String = ""
) {
    val filtered: List<GuardianUi>
        get() {
            val q = query.trim().lowercase()
            if (q.isEmpty()) return items
            return items.filter { g ->
                g.nom.lowercase().contains(q) ||
                        g.prenom.lowercase().contains(q) ||
                        (g.email?.lowercase()?.contains(q) == true) ||
                        (g.telephone?.contains(q) == true) ||
                        (g.ville?.lowercase()?.contains(q) == true)
            }
        }
}

@HiltViewModel
class GuardianListViewModel @Inject constructor(
    private val db: FirebaseFirestore
) : ViewModel() {

    private val _ui = MutableStateFlow(GuardianListState(loading = true))
    val ui: StateFlow<GuardianListState> = _ui

    init {
        viewModelScope.launch { load() }
    }

    fun onChangeQuery(v: String) {
        _ui.update { it.copy(query = v) }
    }

    fun refresh() {
        viewModelScope.launch { load() }
    }

    private suspend fun load() {
        _ui.update { it.copy(loading = true, error = null) }
        try {
            // Récupère les guardians les plus récents (updatedAt desc, fallback sur nom)
            val snap = db.collection("guardians")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .limit(500) // suffisant pour un club; adapter si besoin (paging plus tard)
                .get().await()

            val list = snap.documents.map { d ->
                GuardianUi(
                    id = d.id,
                    nom = (d.getString("nom") ?: "").trim(),
                    prenom = (d.getString("prenom") ?: "").trim(),
                    email = d.getString("email"),
                    telephone = d.getString("telephone"),
                    ville = d.getString("ville"),
                    relation = d.getString("relation")
                )
            }.sortedWith( // double tri : updatedAt desc (via requête), puis nom/prénom pour stabilité
                compareBy<GuardianUi> { it.nom }.thenBy { it.prenom }
            )

            _ui.update { it.copy(loading = false, items = list, error = null) }
        } catch (e: Exception) {
            _ui.update { it.copy(loading = false, error = e.message ?: "Erreur de chargement") }
        }
    }

    suspend fun deleteGuardianSafely(guardianId: String): Boolean {
        _ui.update { it.copy(loading = true, error = null) }
        return try {
            // 1) Vérifier qu’aucun adhérent n’est rattaché à ce guardian
            val primarySnap = db.collection("adherents")
                .whereEqualTo("primaryGuardianId", guardianId)
                .limit(1)
                .get()
                .await()

            if (!primarySnap.isEmpty) {
                _ui.update { it.copy(loading = false) }
                return false
            }

            val listSnap = db.collection("adherents")
                .whereArrayContains("guardianIds", guardianId)
                .limit(1)
                .get()
                .await()

            if (!listSnap.isEmpty) {
                _ui.update { it.copy(loading = false) }
                return false
            }

            // 2) OK pour supprimer
            db.collection("guardians").document(guardianId).delete().await()

            // 3) Mettre à jour la liste locale
            _ui.update { state ->
                state.copy(
                    loading = false,
                    items = state.items.filterNot { it.id == guardianId },
                    error = null
                )
            }
            true
        } catch (e: Exception) {
            _ui.update { it.copy(loading = false, error = e.message ?: "Échec de la suppression") }
            false
        }
    }

}
