@file:OptIn(ExperimentalMaterial3Api::class)

package com.antechrist.adherentsapp.ui.screens.guardian

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.antechrist.adherentsapp.ui.screens.guardian.components.GuardianListItem
import kotlinx.coroutines.launch

@Composable
fun GuardianListScreen(
    onBack: () -> Unit,
    onEditGuardian: (String) -> Unit,     // obligatoire
    vm: GuardianListViewModel = hiltViewModel()
) {
    val ui by vm.ui.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val screenScope = rememberCoroutineScope()

    var toDelete by remember { mutableStateOf<GuardianUi?>(null) }
    var showConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(ui.error) {
        ui.error?.let { screenScope.launch { snackbar.showSnackbar(it) } }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Responsables") },
                windowInsets = WindowInsets(0, 0, 0, 0),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbar) }
    ) { paddings ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(paddings)
        ) {
            // Barre de recherche
            OutlinedTextField(
                value = ui.query,
                onValueChange = vm::onChangeQuery,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                placeholder = { Text("Rechercher (nom, email, téléphone)…") },
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Search),
            )

            // Contenu
            if (ui.loading && ui.items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                SwipeToRefreshBox(
                    isRefreshing = ui.loading,
                    onRefresh = { vm.refresh() }
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        items(ui.filtered, key = { it.id }) { g ->
                            val dismissState = rememberSwipeToDismissBoxState(
                                confirmValueChange = { value ->
                                    when (value) {
                                        SwipeToDismissBoxValue.StartToEnd -> { // → Éditer
                                            onEditGuardian(g.id)
                                            false // ne pas dismiss visuellement
                                        }
                                        SwipeToDismissBoxValue.EndToStart -> { // ← Supprimer
                                            toDelete = g
                                            showConfirm = true
                                            false // ne pas dismiss visuellement
                                        }
                                        else -> false
                                    }
                                }
                            )
                            // ✅ scope par item pour appeler snapTo/animateTo
                            val itemScope = rememberCoroutineScope()

                            SwipeToDismissBox(
                                state = dismissState,
                                enableDismissFromStartToEnd = true,
                                enableDismissFromEndToStart = true,
                                backgroundContent = {
                                    val isDelete = when (dismissState.targetValue) {
                                        SwipeToDismissBoxValue.EndToStart -> true
                                        else -> false
                                    }
                                    val bgColor = if (isDelete)
                                        MaterialTheme.colorScheme.errorContainer
                                    else
                                        MaterialTheme.colorScheme.secondaryContainer
                                    val icon = if (isDelete) Icons.Filled.Delete else Icons.Filled.Edit
                                    val label = if (isDelete) "Supprimer" else "Éditer"

                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(horizontal = 8.dp),
                                        contentAlignment = if (isDelete) Alignment.CenterEnd else Alignment.CenterStart
                                    ) {
                                        AssistChip(
                                            onClick = {
                                                itemScope.launch {
                                                    if (isDelete) {
                                                        toDelete = g
                                                        showConfirm = true
                                                    } else {
                                                        onEditGuardian(g.id)
                                                    }
                                                    // 🔄 Ramène l’item à l’état neutre après action
                                                    dismissState.snapTo(SwipeToDismissBoxValue.Settled)
                                                    // (ou: dismissState.animateTo(SwipeToDismissBoxValue.Settled))
                                                }
                                            },
                                            label = { Text(label) },
                                            leadingIcon = { Icon(icon, contentDescription = null) },
                                            colors = AssistChipDefaults.assistChipColors(
                                                containerColor = bgColor
                                            )
                                        )
                                    }
                                },
                                content = {
                                    GuardianListItem(
                                        guardian = g,
                                        onClick = {
                                            // Tap simple = éditer
                                            onEditGuardian(g.id)
                                            // Optionnel : si tu veux “replier” le swipe après un tap :
                                            itemScope.launch {
                                                dismissState.snapTo(SwipeToDismissBoxValue.Settled)
                                            }
                                        }
                                    )
                                }
                            )
                        }
                        if (ui.filtered.isEmpty()) {
                            item {
                                Box(
                                    Modifier
                                        .fillParentMaxSize()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("Aucun responsable")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation suppression avec sécurité côté ViewModel
    if (showConfirm && toDelete != null) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("Supprimer le responsable ?") },
            text = {
                Text(
                    "Cette action est définitive.\n" +
                            "La suppression est possible uniquement si aucun adhérent n’est rattaché " +
                            "à ce responsable (ni comme responsable principal, ni dans la liste des responsables)."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirm = false
                        val gid = toDelete!!.id
                        toDelete = null
                        screenScope.launch {
                            val ok = vm.deleteGuardianSafely(gid)
                            if (ok) snackbar.showSnackbar("Responsable supprimé")
                            else snackbar.showSnackbar("Suppression impossible : responsable rattaché à un ou plusieurs adhérents")
                        }
                    }
                ) { Text("Supprimer") }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("Annuler") }
            }
        )
    }
}

/** Mini wrapper rafraîchissement (Material3 – sans dépendance externe) */
@Composable
private fun SwipeToRefreshBox(
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        content()
        if (isRefreshing) {
            // overlay léger (optionnel)
        }
    }
}
