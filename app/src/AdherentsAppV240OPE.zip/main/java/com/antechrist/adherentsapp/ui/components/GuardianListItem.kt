package com.antechrist.adherentsapp.ui.screens.guardian.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.antechrist.adherentsapp.ui.screens.guardian.GuardianUi

@Composable
fun GuardianListItem(
    guardian: GuardianUi,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ListItem(
        headlineContent = {
            Text(
                text = "${guardian.nom} ${guardian.prenom}".trim(),
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        },
        supportingContent = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                guardian.email?.takeIf { it.isNotBlank() }?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                guardian.telephone?.takeIf { it.isNotBlank() }?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                guardian.ville?.takeIf { it.isNotBlank() }?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        },
        leadingContent = {
            Surface(
                shape = CircleShape,
                tonalElevation = 2.dp,
                modifier = Modifier.size(40.dp)
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    val initials = buildString {
                        append(guardian.nom.firstOrNull() ?: '#')
                        append(guardian.prenom.firstOrNull() ?: ' ')
                    }.uppercase()
                    Text(initials, style = MaterialTheme.typography.titleSmall)
                }
            }
        },
        trailingContent = {
            guardian.relation?.takeIf { it.isNotBlank() }?.let {
                AssistChip(onClick = {}, label = { Text(it.replaceFirstChar { c -> c.uppercase() }) })
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
}
