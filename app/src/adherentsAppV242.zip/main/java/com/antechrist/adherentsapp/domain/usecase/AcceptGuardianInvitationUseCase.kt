package com.antechrist.adherentsapp.domain.usecase

import com.antechrist.adherentsapp.domain.repository.GuardianInvitationsRepository
import com.antechrist.adherentsapp.domain.repository.GuardiansRepository
import com.google.firebase.auth.FirebaseAuth
import javax.inject.Inject

//class AcceptGuardianInvitationUseCase @Inject constructor(
//    private val repo: GuardianInvitationsRepository
//) {
//    suspend operator fun invoke(inviteId: String, guardianId: String) {
//        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: error("Utilisateur non connecté")
//        repo.accept(inviteId = inviteId, guardianId = guardianId, authUid = uid)
//    }
//}

class AcceptGuardianInvitationUseCase @Inject constructor(
    private val repo: GuardianInvitationsRepository
) {
    suspend operator fun invoke(inviteId: String, guardianId: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
            ?: error("Utilisateur non connecté")

        repo.accept(inviteId = inviteId, guardianId = guardianId, authUid = uid)
    }
}
