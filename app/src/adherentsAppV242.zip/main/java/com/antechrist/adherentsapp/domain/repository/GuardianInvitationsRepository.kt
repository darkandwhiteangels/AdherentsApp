package com.antechrist.adherentsapp.domain.repository

import com.antechrist.adherentsapp.domain.model.GuardianInvitation

interface GuardianInvitationsRepository {
    suspend fun findPendingFor(emailLower: String, seasonKey: String): GuardianInvitation?
    suspend fun accept(inviteId: String, guardianId: String, authUid: String)

    suspend fun findLatestPendingForEmail(emailLower: String): GuardianInvitation?

    //suspend fun getPendingForEmail(emailLower: String): GuardianInvitation?
}
