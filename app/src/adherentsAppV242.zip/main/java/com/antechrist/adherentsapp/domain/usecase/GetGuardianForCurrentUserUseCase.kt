//package com.antechrist.adherentsapp.domain.usecase
//
//import com.antechrist.adherentsapp.domain.model.Guardian
//import com.antechrist.adherentsapp.domain.repository.GuardiansRepository
//import javax.inject.Inject
//
//class GetGuardianForCurrentUserUseCase @Inject constructor(
//    private val repo: GuardiansRepository
//) {
//    suspend operator fun invoke(authUid: String): Guardian? {
//        return repo.getByAuthUid(authUid)
//    }
//}
package com.antechrist.adherentsapp.domain.usecase

import com.antechrist.adherentsapp.domain.model.Guardian
import com.antechrist.adherentsapp.domain.repository.GuardiansRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

/**
 * Récupère le Guardian associé au user actuellement connecté.
 *
 * Processus :
 * 1. Récupère l'UID Firebase Auth du user connecté
 * 2. Lit le doc users/{uid} pour obtenir le guardianId
 * 3. Récupère le Guardian via guardianId
 */
class GetGuardianForCurrentUserUseCase @Inject constructor(
    private val guardiansRepository: GuardiansRepository,
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) {
    suspend operator fun invoke(): Guardian? {
        // 1. Récupérer l'UID du user connecté
        val uid = auth.currentUser?.uid ?: return null

        // 2. Lire le doc users/{uid} pour récupérer le guardianId
        val userDoc = firestore.collection("users")
            .document(uid)
            .get()
            .await()

        if (!userDoc.exists()) {
            return null
        }

        val guardianId = userDoc.getString("guardianId") ?: return null

        // 3. Récupérer le Guardian
        return guardiansRepository.getById(guardianId)
    }
}