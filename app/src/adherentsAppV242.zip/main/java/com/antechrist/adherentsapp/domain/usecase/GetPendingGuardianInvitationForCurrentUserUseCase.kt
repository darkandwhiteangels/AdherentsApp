//package com.antechrist.adherentsapp.domain.usecase
//
//import android.util.Log
//import com.antechrist.adherentsapp.domain.model.GuardianInvitation
//import com.antechrist.adherentsapp.domain.repository.GuardianInvitationsRepository
//import com.google.firebase.auth.FirebaseAuth
//import javax.inject.Inject
//
//class GetPendingGuardianInvitationForCurrentUserUseCase @Inject constructor(
//    private val repo: GuardianInvitationsRepository
//) {
//    suspend operator fun invoke(): GuardianInvitation? {
//        Log.d("GetPendingInvite", "==========================================")
//        Log.d("GetPendingInvite", "=== DÉBUT USE CASE ===")
//
//        val currentUser = FirebaseAuth.getInstance().currentUser
//        Log.d("GetPendingInvite", "User UID: ${currentUser?.uid}")
//        Log.d("GetPendingInvite", "User Email: ${currentUser?.email}")
//
//        val email = currentUser
//            ?.email
//            ?.trim()
//            ?.lowercase()
//
//        if (email == null) {
//            Log.w("GetPendingInvite", "⚠️ Email est NULL - impossible de chercher l'invitation")
//            Log.d("GetPendingInvite", "========================================")
//            return null
//        }
//
//        Log.d("GetPendingInvite", "Email formaté pour recherche: '$email'")
//        Log.d("GetPendingInvite", "Appel du repository...")
//
//        try {
//            val result = repo.findLatestPendingForEmail(emailLower = email)
//
//            if (result == null) {
//                Log.w("GetPendingInvite", "⚠️ Repository a retourné NULL")
//                Log.w("GetPendingInvite", "Soit aucune invitation existe pour cet email")
//                Log.w("GetPendingInvite", "Soit il y a eu une erreur Firestore (vérifier les logs Firestore)")
//            } else {
//                Log.d("GetPendingInvite", "✅ Invitation trouvée par le repository")
//                Log.d("GetPendingInvite", "  - ID: ${result.id}")
//                Log.d("GetPendingInvite", "  - GuardianId: ${result.guardianId}")
//                Log.d("GetPendingInvite", "  - Status: ${result.status}")
//            }
//
//            Log.d("GetPendingInvite", "=== FIN USE CASE ===")
//            Log.d("GetPendingInvite", "==========================================")
//            return result
//
//        } catch (e: Exception) {
//            Log.e("GetPendingInvite", "❌ ERREUR dans le repository", e)
//            Log.e("GetPendingInvite", "Type: ${e.javaClass.simpleName}")
//            Log.e("GetPendingInvite", "Message: ${e.message}")
//            Log.d("GetPendingInvite", "========================================")
//            throw e
//        }
//    }
//}
package com.antechrist.adherentsapp.domain.usecase

import android.util.Log
import com.antechrist.adherentsapp.domain.model.GuardianInvitation
import com.antechrist.adherentsapp.domain.repository.GuardianInvitationsRepository
import com.google.firebase.auth.FirebaseAuth
import javax.inject.Inject

private const val TAG = "GetPendingInvite"

class GetPendingGuardianInvitationForCurrentUserUseCase @Inject constructor(
    private val repo: GuardianInvitationsRepository
) {
    suspend operator fun invoke(): GuardianInvitation? {
        Log.d(TAG, "════════════════════════════════════════════")
        Log.d(TAG, "🔍 TEST 1: allow list sur guardian_invitations")

        val currentUser = FirebaseAuth.getInstance().currentUser
        val email = currentUser?.email?.lowercase()

        Log.d(TAG, "📍 Location: /guardian_invitations")
        Log.d(TAG, "🔧 Operation: list (query)")
        Log.d(TAG, "✅ Authenticated: ${currentUser != null}")
        Log.d(TAG, "🆔 Auth UID: ${currentUser?.uid}")
        Log.d(TAG, "📧 Auth Email: ${currentUser?.email}")
        Log.d(TAG, "📧 Auth Email (lowercase): $email")
        Log.d(TAG, "🔎 Query: emailLower == $email && status == PENDING")

        if (email == null) {
            Log.w(TAG, "⚠️ Email null, impossible de chercher l'invitation")
            Log.d(TAG, "════════════════════════════════════════════")
            return null
        }

        // Simuler les custom claims pour les logs
        Log.d(TAG, "📋 Custom claims (simulé):")
        Log.d(TAG, "   - role: parent")
        Log.d(TAG, "   - email: ${currentUser.email}")

        return try {
            val result = repo.findLatestPendingForEmail(email)

            if (result != null) {
                Log.d(TAG, "📊 Result: ✅ Invitation PENDING trouvée")
                Log.d(TAG, "   - ID: ${result.id}")
                Log.d(TAG, "   - Guardian ID: ${result.guardianId}")
                Log.d(TAG, "   - Email: ${result.emailLower}")
                Log.d(TAG, "   - Status: ${result.status}")
                Log.d(TAG, "   - Season: ${result.seasonKey}")
            } else {
                Log.d(TAG, "📊 Result: ⚠️ Aucune invitation PENDING trouvée")
            }

            Log.d(TAG, "════════════════════════════════════════════")
            result

        } catch (e: Exception) {
            Log.e(TAG, "❌ ERREUR dans le repository", e)
            Log.e(TAG, "Type: ${e.javaClass.simpleName}")
            Log.e(TAG, "Message: ${e.message}")
            Log.e(TAG, "Stack trace:", e)
            Log.d(TAG, "════════════════════════════════════════════")
            throw e
        }
    }
}