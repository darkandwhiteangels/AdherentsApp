package com.antechrist.adherentsapp.data.firestore

import android.util.Log
import com.antechrist.adherentsapp.domain.model.GuardianInvitation
import com.antechrist.adherentsapp.domain.repository.GuardianInvitationsRepository
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class GuardianInvitationsRepositoryImpl @Inject constructor(
    private val db: FirebaseFirestore
) : GuardianInvitationsRepository {

    private val col = db.collection("guardian_invitations")
    private val guardians = db.collection("guardians")

    override suspend fun findPendingFor(emailLower: String, seasonKey: String): GuardianInvitation? {
        val qs = col
            .whereEqualTo("emailLower", emailLower)
            .whereEqualTo("seasonKey", seasonKey)
            .whereEqualTo("status", "PENDING")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(1)
            .get()
            .await()

        val doc = qs.documents.firstOrNull() ?: return null
        return GuardianInvitation(
            id = doc.id,
            guardianId = doc.getString("guardianId") ?: return null,
            emailLower = doc.getString("emailLower") ?: emailLower,
            seasonKey = doc.getString("seasonKey") ?: seasonKey,
            status = doc.getString("status") ?: "PENDING"
        )
    }

    override suspend fun accept(inviteId: String, guardianId: String, authUid: String) {
        val inviteRef = col.document(inviteId)
        val guardianRef = guardians.document(guardianId)

        val batch = db.batch()

        // 1) Invitation -> ACCEPTED
        batch.set(
            inviteRef,
            mapOf(
                "status" to "ACCEPTED",
                "acceptedByUid" to authUid,
                "acceptedAt" to System.currentTimeMillis()
            ),
            SetOptions.merge()
        )

        // 2) Guardian -> authUid
        batch.set(
            guardianRef,
            mapOf(
                "authUid" to authUid,
                "updatedAt" to System.currentTimeMillis()
            ),
            SetOptions.merge()
        )

        batch.commit().await()
    }

    override suspend fun findLatestPendingForEmail(emailLower: String): GuardianInvitation? {
        Log.d("GuardianInvitRepo", "==========================================")
        Log.d("GuardianInvitRepo", "=== DÉBUT QUERY FIRESTORE ===")

        val e = emailLower.trim().lowercase()

        if (e.isEmpty()) {
            Log.w("GuardianInvitRepo", "⚠️ Email vide après trim/lowercase")
            Log.d("GuardianInvitRepo", "========================================")
            return null
        }

        Log.d("GuardianInvitRepo", "Email recherché: '$e'")
        Log.d("GuardianInvitRepo", "Collection: guardian_invitations")
        Log.d("GuardianInvitRepo", "Filtres:")
        Log.d("GuardianInvitRepo", "  - emailLower == '$e'")
        Log.d("GuardianInvitRepo", "  - status == 'PENDING'")
        Log.d("GuardianInvitRepo", "  - orderBy createdAt DESC")
        Log.d("GuardianInvitRepo", "  - limit 1")

        try {
            Log.d("GuardianInvitRepo", "🔍 Exécution de la query Firestore...")

            val qs = col
                .whereEqualTo("emailLower", e)
                .whereEqualTo("status", "PENDING")
                .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(1)
                .get()
                .await()

            Log.d("GuardianInvitRepo", "✅ Query exécutée sans erreur")
            Log.d("GuardianInvitRepo", "Nombre de documents retournés: ${qs.documents.size}")

            if (qs.documents.isEmpty()) {
                Log.w("GuardianInvitRepo", "⚠️ Aucun document trouvé")
                Log.w("GuardianInvitRepo", "Vérifiez dans Firebase Console:")
                Log.w("GuardianInvitRepo", "  1. Qu'une invitation existe avec emailLower='$e'")
                Log.w("GuardianInvitRepo", "  2. Que status='PENDING'")
                Log.w("GuardianInvitRepo", "  3. Les règles Firestore permettent la lecture")
                Log.d("GuardianInvitRepo", "========================================")
                return null
            }

            val doc = qs.documents.first()
            Log.d("GuardianInvitRepo", "📄 Document trouvé:")
            Log.d("GuardianInvitRepo", "  - Document ID: ${doc.id}")
            Log.d("GuardianInvitRepo", "  - Data: ${doc.data}")

            val guardianId = doc.getString("guardianId")
            val seasonKey = doc.getString("seasonKey") ?: ""
            val status = doc.getString("status") ?: "PENDING"
            val emailFromDoc = doc.getString("emailLower") ?: e

            if (guardianId == null) {
                Log.e("GuardianInvitRepo", "❌ guardianId est NULL dans le document !")
                Log.d("GuardianInvitRepo", "========================================")
                return null
            }

            val invitation = GuardianInvitation(
                id = doc.id,
                guardianId = guardianId,
                emailLower = emailFromDoc,
                seasonKey = seasonKey,
                status = status
            )

            Log.d("GuardianInvitRepo", "✅ Invitation créée:")
            Log.d("GuardianInvitRepo", "  - id: ${invitation.id}")
            Log.d("GuardianInvitRepo", "  - guardianId: ${invitation.guardianId}")
            Log.d("GuardianInvitRepo", "  - emailLower: ${invitation.emailLower}")
            Log.d("GuardianInvitRepo", "  - seasonKey: ${invitation.seasonKey}")
            Log.d("GuardianInvitRepo", "  - status: ${invitation.status}")
            Log.d("GuardianInvitRepo", "=== FIN QUERY FIRESTORE ===")
            Log.d("GuardianInvitRepo", "========================================")

            return invitation

        } catch (e: Exception) {
            Log.e("GuardianInvitRepo", "❌❌❌ ERREUR FIRESTORE ❌❌❌")
            Log.e("GuardianInvitRepo", "Type d'erreur: ${e.javaClass.simpleName}")
            Log.e("GuardianInvitRepo", "Message: ${e.message}")
            Log.e("GuardianInvitRepo", "Stack trace complète:", e)

            // Si c'est une erreur de permission, on le log spécifiquement
            if (e.message?.contains("PERMISSION_DENIED") == true) {
                Log.e("GuardianInvitRepo", "")
                Log.e("GuardianInvitRepo", "🔒 PERMISSION_DENIED détectée !")
                Log.e("GuardianInvitRepo", "Causes possibles:")
                Log.e("GuardianInvitRepo", "  1. Les règles Firestore n'ont pas été déployées")
                Log.e("GuardianInvitRepo", "  2. La fonction authEmailLower() retourne NULL")
                Log.e("GuardianInvitRepo", "  3. La fonction isGuardianEditor() retourne false")
                Log.e("GuardianInvitRepo", "  4. L'utilisateur n'a pas les claims nécessaires")
                Log.e("GuardianInvitRepo", "")
            }

            Log.d("GuardianInvitRepo", "========================================")
            throw e
        }
    }
}

//match /guardian_invitations/{inviteId} {
//    // GET : Lecture d'un document spécifique
//    allow get: if
//        isGuardianEditor()
//                ||
//                (
//                        request.auth != null
//                                && authEmailLower() != null
//                                && resource.data.emailLower == authEmailLower()
//                        );
//
//    // LIST : Queries - CORRIGÉ pour les parents
//    allow list: if
//        isGuardianEditor()
//                ||
//                (
//                        request.auth != null
//                                && authEmailLower() != null
//                        );
//
//    // CREATE : Seulement le staff
//    allow create: if isGuardianEditor()
//            && isValidGuardianInvitationCreate(request.resource.data);
//
//    // UPDATE : Staff peut annuler, utilisateur peut accepter
//    allow update: if
//                          (isGuardianEditor()
//        && isValidGuardianInvitationCancel(resource.data, request.resource.data)
//    )
//            ||
//            (
//                    request.auth != null
//                            && authEmailLower() != null
//                            && resource.data.emailLower == authEmailLower()
//                            && isValidGuardianInvitationAccept(resource.data, request.resource.data)
//                    );
//
//    allow delete: if isSuperAdmin();
//}



//match /guardians/{gid} {
//    allow read, list: if isStaff() || isFinanceManager() || isSecretary();
//
//    // Create: staff uniquement + contact fields
//    allow create: if isGuardianEditor() && hasContactFields(request.resource.data);
//
//    // Update:
//    // A) staff: édition normale guardian (comme avant)
//    // B) parent: liaison authUid STRICTE (une seule fois)
//    allow update: if
//                          (isGuardianEditor() && hasContactFields(request.resource.data))
//            ||
//            (request.auth != null && isGuardianAuthUidLinkOnly(resource.data, request.resource.data));
//
//    allow delete: if isSuperAdmin();
//}