package com.antechrist.adherentsapp.domain.usecase

import com.antechrist.adherentsapp.domain.model.Adherent
import com.antechrist.adherentsapp.domain.repository.AdherentsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

/**
 * Récupère tous les adhérents du foyer du parent connecté.
 *
 * Utilise GetGuardianForCurrentUserUseCase pour obtenir le guardian du parent,
 * puis filtre les adhérents qui ont ce guardianId dans leur liste guardianIds.
 */
class GetMyHouseholdAdherentsUseCase @Inject constructor(
    private val getGuardianForCurrentUserUseCase: GetGuardianForCurrentUserUseCase,
    private val adherentsRepository: AdherentsRepository
) {
    operator fun invoke(): Flow<List<Adherent>> = flow {
        // 1. Récupérer le guardian du user connecté
        val guardian = getGuardianForCurrentUserUseCase()

        if (guardian == null) {
            emit(emptyList())
            return@flow
        }

        // 2. Écouter tous les adhérents et filtrer ceux du foyer
        adherentsRepository.streamAll().collect { allAdherents ->
            val myAdherents = allAdherents.filter { adherent ->
                adherent.guardianIds?.contains(guardian.id) == true
            }
            emit(myAdherents)
        }
    }
}