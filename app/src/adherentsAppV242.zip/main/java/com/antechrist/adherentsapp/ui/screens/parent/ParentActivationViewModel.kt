package com.antechrist.adherentsapp.ui.screens.parent

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.antechrist.adherentsapp.domain.usecase.AcceptGuardianInvitationUseCase
import com.antechrist.adherentsapp.domain.usecase.GetPendingGuardianInvitationForCurrentUserUseCase
import com.antechrist.adherentsapp.domain.usecase.IsGuardianLinkedToCurrentUserUseCase
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class ParentActivationState { Loading, Success, NoInvite, Error }

data class ParentActivationUi(
    val state: ParentActivationState = ParentActivationState.Loading,
    val error: String? = null
)

@HiltViewModel
class ParentActivationViewModel @Inject constructor(
    private val isLinked: IsGuardianLinkedToCurrentUserUseCase,
    private val getPendingInvite: GetPendingGuardianInvitationForCurrentUserUseCase,
    private val acceptInvite: AcceptGuardianInvitationUseCase
) : ViewModel() {

    private val _ui = MutableStateFlow(ParentActivationUi())
    val ui: StateFlow<ParentActivationUi> = _ui.asStateFlow()

    fun start() {
        viewModelScope.launch {
            _ui.update { it.copy(state = ParentActivationState.Loading, error = null) }

            try {
                Log.d("ParentActivation", "========================================")
                Log.d("ParentActivation", "=== DÉBUT ACTIVATION PARENT ===")
                Log.d("ParentActivation", "Tentative de récupération de l'invitation...")

                val uid = FirebaseAuth.getInstance().currentUser?.uid
                    ?: error("Utilisateur non connecté")

                // 1) Déjà lié ? -> OK direct (idempotent)
                val alreadyLinked = try {
                    isLinked()
                } catch (e: Exception) {
                    Log.w("ParentActivation", "⚠️ isLinked() a échoué: ${e.message}")
                    false
                }

                if (alreadyLinked) {
                    Log.d("ParentActivation", "✅ Compte déjà lié à un guardian (uid=$uid) -> SUCCESS")
                    _ui.update { it.copy(state = ParentActivationState.Success, error = null) }
                    Log.d("ParentActivation", "=== FIN ACTIVATION PARENT ===")
                    Log.d("ParentActivation", "========================================")
                    return@launch
                }

                // 2) Sinon -> chercher invitation PENDING
                val invite = getPendingInvite()
                if (invite == null) {
                    Log.w("ParentActivation", "⚠️ AUCUNE invitation PENDING trouvée !")
                    _ui.update { it.copy(state = ParentActivationState.NoInvite, error = null) }
                    Log.d("ParentActivation", "=== FIN ACTIVATION PARENT ===")
                    Log.d("ParentActivation", "========================================")
                    return@launch
                }

                Log.d("ParentActivation", "✅ Invitation trouvée !")
                Log.d("ParentActivation", "  - ID: ${invite.id}")
                Log.d("ParentActivation", "  - GuardianId: ${invite.guardianId}")
                Log.d("ParentActivation", "  - Email: ${invite.emailLower}")
                Log.d("ParentActivation", "  - SeasonKey: ${invite.seasonKey}")
                Log.d("ParentActivation", "  - Status: ${invite.status}")

                Log.d("ParentActivation", "Acceptation de l'invitation...")
                acceptInvite(invite.id, invite.guardianId)

                Log.d("ParentActivation", "✅ Invitation acceptée avec succès !")
                _ui.update { it.copy(state = ParentActivationState.Success, error = null) }
                Log.d("ParentActivation", "=== FIN ACTIVATION PARENT ===")
                Log.d("ParentActivation", "========================================")

            } catch (e: Exception) {
                Log.e("ParentActivation", "❌ ERREUR lors de l'activation", e)
                Log.e("ParentActivation", "Type d'erreur: ${e.javaClass.simpleName}")
                Log.e("ParentActivation", "Message: ${e.message}")
                _ui.update { it.copy(state = ParentActivationState.Error, error = e.message) }
                Log.d("ParentActivation", "========================================")
            }
        }
    }
}
