package com.antechrist.adherentsapp.ui.screens.parent

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.delay

@Composable
fun ParentActivationScreen(
    onDone: () -> Unit,
    onBackToLogin: () -> Unit,
    vm: ParentActivationViewModel = hiltViewModel()
) {
    val ui by vm.ui.collectAsState()

    LaunchedEffect(Unit) { vm.start() }

    // ✅ CORRECTION : Navigation automatique lors du succès
    LaunchedEffect(ui.state) {
        if (ui.state == ParentActivationState.Success) {
            // Petit délai pour que l'utilisateur voie le message de succès
            // delay(1500)
            onDone()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Activation parent", style = MaterialTheme.typography.titleLarge)

            when (ui.state) {
                ParentActivationState.Loading -> {
                    CircularProgressIndicator()
                    Text("Vérification de l'invitation en cours…")
                }

                ParentActivationState.Success -> {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )
                    Text("Compte activé ✅")
                    Text(
                        "Redirection vers votre espace parent...",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    // ✅ Indicateur de progression pendant le délai
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                ParentActivationState.NoInvite -> {
                    Text("Aucune invitation en attente pour ce compte.")
                    Text(
                        "Demande au club de t'envoyer une invitation depuis la fiche adhérent.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = onBackToLogin, modifier = Modifier.fillMaxWidth()) {
                        Text("Retour")
                    }
                }

                ParentActivationState.Error -> {
                    Text("Erreur : ${ui.error ?: "inconnue"}", color = MaterialTheme.colorScheme.error)
                    Button(onClick = vm::start, modifier = Modifier.fillMaxWidth()) {
                        Text("Réessayer")
                    }
                    OutlinedButton(onClick = onBackToLogin, modifier = Modifier.fillMaxWidth()) {
                        Text("Retour")
                    }
                }
            }
        }
    }
}